package com.rvasa;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.MutableDateTime;

import com.rvasa.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.TextView;

/** This application shows how to use dialogs, and working with listeners
 * 
 * @author Rajesh Vasa
 */
public class UpTimeActivity extends Activity 
{
	private static final int FUTURE_DATE_DIALOG = 0;
    private static final int EXIT_DIALOG = 1;
    
	// Assumption that any one running app will be born 10 years near 1986? 
	private MutableDateTime mdt = new MutableDateTime(1986,6,15,10,10,0,0);
	
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide title bar
        setContentView(R.layout.main);
        configureDatePicker();
        updateUpTime();
    }
    
    private void configureDatePicker()
    {
        DatePicker dp = (DatePicker) findViewById(R.id.dobPicker);
        
        // create an anonymous listener
        DatePicker.OnDateChangedListener dListener = new DatePicker.OnDateChangedListener() {
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth)
            {
                DateTime userSet = new DateTime(year, monthOfYear+1, dayOfMonth, 0, 0, 0, 0);
                DateTime now = new DateTime();
                if (userSet.isAfter(now))
                {
                    showDialog(FUTURE_DATE_DIALOG);
                }
                else
                {
                    mdt.setYear(year);
                    mdt.setMonthOfYear(monthOfYear+1);
                    mdt.setDayOfMonth(dayOfMonth);
                    updateUpTime();             
                }
            }
        };
        
        // initiliase date picker and register the listener
        dp.init(mdt.getYear(), mdt.getMonthOfYear()-1, mdt.getDayOfMonth(), 
                dListener);
    }
    
	private void updateUpTime()
	{
		DateTime now = new DateTime();
		int uptimeInDays = Days.daysBetween(mdt, now).getDays();
		TextView upTimeText = (TextView) findViewById(R.id.upTimeText);
		upTimeText.setText(uptimeInDays+" days");
	}
	
    public void onBackPressed()
    {
    		showDialog(EXIT_DIALOG);
    }
  
    /** This call back allows us to create various dialogs */
    protected Dialog onCreateDialog(int id)
    {
    		Dialog d = null; // default
    		switch (id)
    		{
    			case EXIT_DIALOG: 
    				d = constructConfirmExitDialog();
    				break;
    			case FUTURE_DATE_DIALOG:
    				d = constructFutureDateDialog();
    				resetDate();
    				break;
    		}
    		return d;
    }
    
    /** Set date to last known safe value */
    private void resetDate()
    {
        DatePicker dp = (DatePicker) findViewById(R.id.dobPicker);
        dp.updateDate(mdt.getYear(), mdt.getMonthOfYear()-1, mdt.getDayOfMonth());
    }

    /** This method constructs the future date dialog */
	private Dialog constructFutureDateDialog()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Error")
			   .setMessage("Future Dates are not allowed!")
		       .setCancelable(false)
		       .setPositiveButton("Dismiss", new DialogInterface.OnClickListener() 
		       {
		           public void onClick(DialogInterface dialog, int id) 
		           {
		        	   		dialog.cancel();
		           }
		       });
		AlertDialog alert = builder.create();
		return alert;		
	}

	/** This method constructs an exit dialog */
	private Dialog constructConfirmExitDialog()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Excuse me")
		       .setIcon(android.R.drawable.ic_menu_help)
			   .setMessage("Are you sure you want to exit?")
		       .setCancelable(false)
		       .setPositiveButton("Yes", new DialogInterface.OnClickListener() 
		       {
		           public void onClick(DialogInterface dialog, int id) 
		           {
		                UpTimeActivity.this.finish();
		           }
		       })
		       .setNegativeButton("No", new DialogInterface.OnClickListener() 
		       {
		           public void onClick(DialogInterface dialog, int id) 
		           {
		                dialog.cancel();
		           }
		       });
		AlertDialog alert = builder.create();
		return alert;
	}
}