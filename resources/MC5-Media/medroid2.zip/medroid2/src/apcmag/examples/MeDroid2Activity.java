
package apcmag.examples;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

/** This is the main activity class for MeDroid 
 * 
 * @author Rajesh Vasa
 * October 2011
 * */
public class MeDroid2Activity extends Activity
{
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide title bar
        setContentView(R.layout.main);
    }
    
    public void showAbout(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.AboutActivity.class); 
        startActivity(intent);
    }
    
    
    public void showServices(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.ServicesActivity.class); 
        startActivity(intent);
    }
    
    public void showPortfolio(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.AboutActivity.class); 
        startActivity(intent);
    }
    
    public void showBlog(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.AboutActivity.class); 
        startActivity(intent);
    }
    
    public void showTweets(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.TwitterActivity.class); 
        startActivity(intent);
    }
    
    public void showContact(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.AboutActivity.class); 
        startActivity(intent);
    }
    
}
