package apcmag.examples;

import android.app.Activity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.widget.TextView;

/**
 * Displays brief information about the person or company
 * 
 * @author Rajesh Vasa
 */
public class AboutActivity extends Activity 
{
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        
        // Make URLs clickable
        TextView tv = (TextView) findViewById(R.id.webURLTextView);
        Linkify.addLinks(tv, Linkify.WEB_URLS);
        
    }

}
