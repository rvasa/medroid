package apcmag.examples;

import android.app.Activity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.widget.TextView;

/**
 * Displays contact information
 * 
 * @author Rajesh Vasa
 */

public class ContactActivity extends Activity 
{
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact);
        
        // Make URLs clickable
        TextView curl = (TextView) findViewById(R.id.contactURL);
        TextView turl = (TextView) findViewById(R.id.twitterURL);
        Linkify.addLinks(curl, Linkify.WEB_URLS);
        Linkify.addLinks(turl, Linkify.WEB_URLS);
    }

}
