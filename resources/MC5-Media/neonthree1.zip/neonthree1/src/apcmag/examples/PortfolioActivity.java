
package apcmag.examples;

import android.app.Activity;
import android.os.Bundle;
import android.text.util.Linkify;
import android.widget.TextView;
import android.widget.VideoView;


public class PortfolioActivity extends Activity
{
    private VideoView videoView;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.portfolio);
        TextView tv = (TextView) findViewById(R.id.moreAtURL);
        Linkify.addLinks(tv, Linkify.ALL);
        //videoView = (VideoView) findViewById(R.id.videoView);
    }
    
    @Override
    protected void onStart()
    {
        super.onStart();
        playVideo();
    }
    
    
    /** Open and play the raw resource directly */
    private void playVideo()
    {
        // location of the android resource
        String path = "android.resource://" + getPackageName() + "/raw/intro";
        
        videoView = (VideoView) findViewById(R.id.videoView);
        videoView.requestFocus();
        videoView.setVideoPath(path);
        videoView.start(); // play video
    }
    
    /** Stop playback of the video and release resources */
    protected void onPause()
    {
        super.onPause();
        videoView.pause();
    }
    
    @Override
    protected void onStop()
    {
        super.onStop();
        videoView.stopPlayback();
    }
    
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        videoView.suspend();
        videoView = null;
    }
    

}
