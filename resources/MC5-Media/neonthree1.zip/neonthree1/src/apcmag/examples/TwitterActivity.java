package apcmag.examples;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

/**
 * This activity will display an image and some information about the person/entity
 * The image used in the example is of Linus Trovals, the Father of Linux
 * 
 * Image Source: http://www.flickr.com/photos/home_of_chaos/4203246501/sizes/o/in/photostream/
 * @author Rajesh Vasa
 */
public class TwitterActivity extends Activity 
{
	private String uagent = "Mozilla/5.0 (Linux; U; Android 2.0; en-us; Droid Build/ESD20) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17";
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.twitter);
        displayTweets();
    }

    /** Display the tweets in the webview -- the user name is obtained from external string resource */
	private void displayTweets() 
	{
		WebView mWebView = (WebView) findViewById(R.id.twitterWebView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        
        // dirty-hack to get around Twitter page load bug when user agent is unknown
        mWebView.getSettings().setUserAgentString(uagent); 

        // get the user name from external string resource XML file
        String username = getResources().getString(R.string.twitter_user_name);
        
        mWebView.loadUrl("http://mobile.twitter.com/"+username);
	}

}
