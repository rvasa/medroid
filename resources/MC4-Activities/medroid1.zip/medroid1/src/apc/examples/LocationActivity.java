package apc.examples;

import android.app.Activity;
import android.os.Bundle;

/**
 * Displays the location of the person on a map
 * Connection to Google Maps not yet implemented.
 * 
 * Image Source: NASA, Blue Marble // http://visibleearth.nasa.gov/view_rec.php?id=2429
 * @author Rajesh Vasa
 */

public class LocationActivity extends Activity 
{
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location);
    }

}
