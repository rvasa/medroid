package apc.examples;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MeDroid1Activity extends Activity 
{
	
    /** Called when the activity is first created. 
     * 
     * Photo of Linus from 
     * 
     * */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    public void aboutMe(View v)
    {
    	Intent intent = new Intent(getApplicationContext(), apc.examples.AboutActivity.class); 
    	startActivity(intent);
    }
    
    public void showTweets(View v)
    {
    	Intent intent = new Intent(getApplicationContext(), apc.examples.TwitterActivity.class); 
    	startActivity(intent);
    }
    
    public void showLocation(View v)
    {
    	Intent intent = new Intent(getApplicationContext(), apc.examples.LocationActivity.class); 
    	startActivity(intent);
    }
    
    
}