package medroid.examples;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This class extends the SQLiteOpenHelper and constructs the database initially.
 * It also shows how to populate the database with default data.
 * 
 * @author Rajesh Vasa, 2011
 */
public class DBHelper extends SQLiteOpenHelper
{
	private static final String DATABASE_NAME="quotes";
	static final String QUOTE_TBL = "quoteTbl";
	static final String NAME="name";
	static final String QUOTE="quote";
	static final String SELECT_ALL = "SELECT _ID, name, quote " + "FROM quoteTbl ORDER BY name";

	public DBHelper(Context context) 
	{
		super(context, DATABASE_NAME, null, 1);
	}
	
	/** Create database */
	public void onCreate(SQLiteDatabase db) 
	{
        String createStmt = "CREATE TABLE "+QUOTE_TBL;
        createStmt += " (_id INTEGER PRIMARY KEY AUTOINCREMENT, ";
        createStmt += NAME+" TEXT, ";
        createStmt += QUOTE+" TEXT);";
        db.execSQL(createStmt);
	    constructDefaultData(db);
	}
	
	/** Open database -- populate default data if none present  */
	public void onOpen(SQLiteDatabase db)
	{
        Cursor c = db.rawQuery(SELECT_ALL, null);
        if (c.getCount() == 0) // table is empty
            constructDefaultData(db);
        super.onOpen(db);
	}
	
	public void constructDefaultData(SQLiteDatabase db)
	{
        android.util.Log.w("QUOTE_DB_HELPER", "Constructing default data!");
        
        // insert content into the table directly
        ContentValues cv = new ContentValues();
        cv.put(NAME, "Master Yoda");
        cv.put(QUOTE, "Do or do not, there is no try");
        db.insert(QUOTE_TBL, null, cv);

        cv.put(NAME, "Thomas Edison");
        cv.put(QUOTE, "Genius is one percent inspiration and 99 percent perspiration.");
        db.insert(QUOTE_TBL, null, cv);
        
        cv.put(NAME, "Albert Einstein");
        cv.put(QUOTE, "Two things are infinite: the universe and human stupidity; and I am not sure about the universe.");
        db.insert(QUOTE_TBL, null, cv);
        
        cv.put(NAME, "John Lennon");
        cv.put(QUOTE, "Time you enjoy wasting, was not wasted.");
        db.insert(QUOTE_TBL, null, cv);
	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) 
	{
		android.util.Log.w("QUOTE_DB_HELPER", "Evil method to upgrade db, will destroy old data");
		db.execSQL("DROP TABLE IF EXISTS "+QUOTE_TBL);
		onCreate(db);
	}
}	
	