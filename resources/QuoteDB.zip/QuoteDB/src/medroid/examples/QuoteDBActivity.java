package medroid.examples;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;

/** 
 * This sample application demonstrates the following:
 * 1. How to use the DBHelper and an sqlite datbase to read, add data.
 * 2. Build simple and custom dialogs (with Yes/No and Ok/Cancel functionality). 
 * 3. Construct contextual menus, and process item clicks in Android
 * 
 * @author Rajesh Vasa, 2011
 */
public class QuoteDBActivity extends ListActivity
{
	private static final int ADD_ID = Menu.FIRST + 1;
    private static final int CLEAR_ID = Menu.FIRST + 2;
    
	private static final int DELETE_ID = Menu.FIRST + 3; // lazy hack :)

	private DBHelper db = null;
	private Cursor personCursor = null;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		db = new DBHelper(this);
		showAllQuotes();		
		registerForContextMenu(getListView());
	}
	
	/** Query database -- and populate results into the list adapter */
	private void showAllQuotes()
	{
		if (personCursor != null) personCursor.close(); // close old cursor		
		personCursor = db.getReadableDatabase().rawQuery(DBHelper.SELECT_ALL, null);
		ListAdapter adapter = new SimpleCursorAdapter(this, R.layout.row,
				personCursor, new String[] { DBHelper.QUOTE, DBHelper.NAME },
				new int[] { R.id.quoteTextView, R.id.nameTextView });
		setListAdapter(adapter);
	}
	
	/** Add a new quote to the database */
	private void processAdd(DialogWrapper wrapper)
	{
		ContentValues values = new ContentValues();
        values.put(DBHelper.NAME, wrapper.getName());
        values.put(DBHelper.QUOTE, wrapper.getQuote());
        Log.w("QUOTE_DB_ACTIVITY", wrapper.getName()+":"+wrapper.getQuote());
		db.getWritableDatabase()
		  .insert(DBHelper.QUOTE_TBL, DBHelper.NAME, values);
		showAllQuotes();
	}
	
	/** Delete all rows in the table */
	private void processClearAll()
	{
	    db.getWritableDatabase().delete(DBHelper.QUOTE_TBL, null, null);
	    showAllQuotes();
	}

	/** Delete the selected quote */
	private void processDelete(long rowId)
	{
		String[] args = { String.valueOf(rowId) };
		db.getWritableDatabase()
		  .delete(DBHelper.QUOTE_TBL, "_ID=?", args);
		showAllQuotes();
	}
	

	public void onDestroy()
	{
		super.onDestroy();
		personCursor.close();
		db.close();
	}

	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add(Menu.NONE, ADD_ID, Menu.NONE, "Add").setIcon(R.drawable.add)
				.setAlphabeticShortcut('a');

        menu.add(Menu.NONE, CLEAR_ID, Menu.NONE, "Clear").setIcon(R.drawable.clear)
        .setAlphabeticShortcut('c');
        
		return (super.onCreateOptionsMenu(menu));
	}

	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case ADD_ID:
			add(); return true;
        case CLEAR_ID:
            clear_all(); return true;
		}

		return (super.onOptionsItemSelected(item));
	}

	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenu.ContextMenuInfo menuInfo)
	{
		menu.add(Menu.NONE, DELETE_ID, Menu.NONE, "Delete")
				.setAlphabeticShortcut('d');
	}

	public boolean onContextItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		    case DELETE_ID:
		        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
		        delete(info.id);
		        return (true);
		}

		return (super.onOptionsItemSelected(item));
	}

	private void add()
	{
		LayoutInflater inflater = LayoutInflater.from(this);
		View addView = inflater.inflate(R.layout.add_new, null);
		final DialogWrapper wrapper = new DialogWrapper(addView);

		new AlertDialog.Builder(this)
				.setTitle(R.string.add_person)
				.setView(addView)
				.setPositiveButton(R.string.ok,
						new DialogInterface.OnClickListener()
						{
							public void onClick(DialogInterface dialog,
									int whichButton)
							{
								processAdd(wrapper);
							}
						})
				.setNegativeButton(R.string.cancel,
						new DialogInterface.OnClickListener()
						{
							public void onClick(DialogInterface dialog,
									int whichButton)
							{
								// ignore, just dismiss
							}
						}).show();
	}
	
	private void clear_all()
	{
        new AlertDialog.Builder(this)
        .setTitle("Clear entire database")
        .setPositiveButton(R.string.yes,
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog,
                            int whichButton)
                    {
                        processClearAll();
                    }
                })
        .setNegativeButton(R.string.no,
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog,
                            int whichButton)
                    {
                        // ignore, just dismiss
                    }
                }).show();
	    
	}

	private void delete(final long rowId)
	{
		if (rowId > 0)
		{
			new AlertDialog.Builder(this)
					.setTitle(R.string.delete_person)
					.setPositiveButton(R.string.ok,
							new DialogInterface.OnClickListener()
							{
								public void onClick(DialogInterface dialog,
										int whichButton)
								{
									processDelete(rowId);
								}
							})
					.setNegativeButton(R.string.cancel,
							new DialogInterface.OnClickListener()
							{
								public void onClick(DialogInterface dialog,
										int whichButton)
								{
									// ignore, just dismiss
								}
							}).show();
		}
	}


	class DialogWrapper
	{
		EditText nameField = null;

		EditText quoteField = null;

		View base = null;

		DialogWrapper(View base)
		{
			this.base = base;
			nameField = (EditText) base.findViewById(R.id.nameEditText);
			quoteField = (EditText) base.findViewById(R.id.quoteEditText);
		}

		String getName()
		{
			return getNameEditText().getText().toString();
		}

		String getQuote()
		{
			return getQuoteEditText().getText().toString();
		}

		private EditText getNameEditText()
		{
			if (nameField == null)
			{
				nameField = (EditText) base.findViewById(R.id.nameEditText);
			}

			return (nameField);
		}

		private EditText getQuoteEditText()
		{
			if (quoteField == null)
			{
				quoteField = (EditText) base.findViewById(R.id.quoteEditText);
			}

			return (quoteField);
		}
	}
}