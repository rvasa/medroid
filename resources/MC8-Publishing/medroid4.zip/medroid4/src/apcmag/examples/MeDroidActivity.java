
package apcmag.examples;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;

/** This is the main activity class for MeDroid 
 * */
public class MeDroidActivity extends Activity
{
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide title bar
        setContentView(R.layout.main);
    }
    
    /** Shows the about activity, logs a message -- see in LogCat View */
    public void showAbout(View v)
    {
        Log.d("MEDROID", "Show About Clicked");  // this is how we log in Android
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.AboutActivity.class); 
        startActivity(intent);
    }
    
    public void showServices(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.ServicesActivity.class); 
        startActivity(intent);
    }
    
    /** Show Blog in an external browser -- via intents */
    public void showBlog(View v)
    {
        String blogURL = getResources().getString(R.string.blog_url);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW);
        browserIntent.setData(Uri.parse(blogURL));
        startActivity(browserIntent);
    }
    
    public void showTweets(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.TwitterActivity.class); 
        startActivity(intent);
    }
    
    public void showPortfolio(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.PortfolioActivity.class); 
        startActivity(intent);
    }
    
    public void showContact(View v)
    {
        Intent intent = new Intent(getApplicationContext(), apcmag.examples.ContactActivity.class); 
        startActivity(intent);
    }
    
}
