package apcmag.examples;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebView;

/**
 * This activity will display an the twitter
 * The user name is set in the strings.xml file
 * 
 * @author Rajesh Vasa
 */
public class TwitterActivity extends Activity 
{
	private String uagent = "Mozilla/5.0 (Linux; U; Android 2.0; en-us; Droid Build/ESD20) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17";
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide title bar
        setContentView(R.layout.twitter);
        displayTweets();
    }

    /** Display the tweets in the webview -- the user name is obtained from external string resource */
	private void displayTweets() 
	{
		WebView mWebView = (WebView) findViewById(R.id.twitterWebView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        
        // dirty-hack to get around Twitter page load bug when user agent is unknown
        mWebView.getSettings().setUserAgentString(uagent); 

        // get the user name from external string resource XML file
        String username = getResources().getString(R.string.twitter_user_name);
        
        mWebView.loadUrl("http://mobile.twitter.com/"+username);
	}

}
