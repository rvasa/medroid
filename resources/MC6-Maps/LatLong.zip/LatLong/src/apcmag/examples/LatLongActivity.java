package apcmag.examples;

import java.util.HashMap;

import swin.examples.R;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/** Display a list of city names and their Lat/Long information */
public class LatLongActivity extends ListActivity
{
	private HashMap<String, Location> locations;
	
	/** Called when the activity is first created. */
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        locations = loadLocationData();
		initializeUI();
	}
	
	/** Load data and initialise the UI */
	private void initializeUI()
	{
		String[] cities = getCityNames();
		// simple_list_item_1 is a SDK provided layout
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 
										android.R.layout.simple_list_item_1, 
										cities);
		setListAdapter(adapter); // use data from this adapter
        displaySelectedCityInfo("Sydney"); // default to Sydney
	}
	
	/** If an item on list is clicked, display its lat/long information */
	public void onListItemClick(ListView l, View v, int position, long id)
	{
		String selectedItem = (String) getListView().getItemAtPosition(position);
		displaySelectedCityInfo(selectedItem);		
	}
	
    /** Provides an array of the city names */
    private String[] getCityNames()
    {
        String[] cities = new String[locations.size()];
        cities = locations.keySet().toArray(cities);
        return cities;
    }
    
    /** Display the name and lat/long information in two text views */
	private void displaySelectedCityInfo(String cityName)
	{
		Location loc = locations.get(cityName);
		TextView cityTextView = (TextView) findViewById(R.id.cityNameTextView);
		TextView locTextView = (TextView) findViewById(R.id.latLongTextView);
		cityTextView.setText(cityName);
		if (loc != null) locTextView.setText(loc.toString());
	}
	
	/** Returns a data structure with lat/long information for some Australian cities */
	private HashMap<String, Location> loadLocationData()
	{
		HashMap<String, Location> locations = new HashMap<String, Location>();
		locations.put("Brisbane", new Location(-27.29, 153.08));
		locations.put("Sydney", new Location(-34.10, 151.01));
		locations.put("Melbourne", new Location(-37.50, 145.01));
		locations.put("Perth", new Location(-31.57, 115.52));
		locations.put("Darwin", new Location(-12.28, 130.51));
        locations.put("Adelaide", new Location(-34.55, 138.36));
        locations.put("Alice Springs", new Location(-23.70, 134.10));
        locations.put("New Castle", new Location(-33.01, 151.80));
        locations.put("Geelong", new Location(-38.1, 144.4));
		return locations;
	}

}