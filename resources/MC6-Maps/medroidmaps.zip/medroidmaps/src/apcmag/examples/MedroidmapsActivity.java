
package apcmag.examples;

import java.util.ArrayList;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Window;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MedroidmapsActivity extends MapActivity
{
    private MapView mapView;
    private MapOverlay locationPinOverlay;

    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); // hide title bar
        setContentView(R.layout.main);

        mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        mapView.setSatellite(false);
        mapView.getController().setZoom(18);        
        
        // set pin image to display in overlay
        Resources res = getResources();
        Drawable location_pin = res.getDrawable(R.drawable.ic_location_pin);
        locationPinOverlay = new MapOverlay(location_pin);
        mapView.getOverlays().add(locationPinOverlay);
        
        addLatLongPoint(-25.3443, 131.0346); // Uluru, NT
        addLatLongPoint(-33.86127, 151.2114); // Circular Quay, Sydney
    }

    private void addLatLongPoint(double pLat, double pLong)
    {
        int lat = (int) (pLat * 1E6);
        int lon = (int) (pLong * 1E6);
        
        GeoPoint gp = new GeoPoint(lat, lon);
        locationPinOverlay.addOverlay(new OverlayItem(gp, "", ""));
        mapView.getController().setCenter(gp);
    }
    
    @Override
    protected boolean isRouteDisplayed()
    {
        return false;
    }

    @SuppressWarnings("rawtypes")
    class MapOverlay extends com.google.android.maps.ItemizedOverlay
    {
        private ArrayList<OverlayItem> overlayItems = new ArrayList<OverlayItem>();

        
        public MapOverlay(Drawable defaultMarker)
        {
            super(boundCenterBottom(defaultMarker));
        }
        
        public void addOverlay(OverlayItem overlay) 
        {
            overlayItems.add(overlay);
            populate();
        }        
        
        @Override
        protected OverlayItem createItem(int i)
        {
            return overlayItems.get(i);
        }

        @Override
        public int size()
        {
            return overlayItems.size();
        }
    }

}
