package medroid.examples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

import swin.examples.R;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * What this application shows:
 * 1. How to read a text file stored as a raw resource.
 * 2. Showing a bunch of words in a simple list
 * 3. Capturing/Processing the list item selection
 * 
 * @author Rajesh Vasa, 2011
 */
public class WordList extends ListActivity
{

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initiliazeUI();
	}

	private void initiliazeUI()
	{
		TextView wordCountTextView = (TextView) findViewById(R.id.wordCountTextView);
		// use a pre-build list style to display words in the array adapter
		ArrayAdapter<String> wordArrayAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1);
		this.setListAdapter(wordArrayAdapter);

		// get text file resource to read, count and display
		InputStream in = getResources().openRawResource(R.raw.android_dev_agreement);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));

		Set<String> words = getWords(br);

		for (String s : words)
			wordArrayAdapter.add(s); // add the words into the adapter

		wordCountTextView.setText("Words: " + words.size());
	}

	/** Show the size of the selected word */
	public void onListItemClick(ListView l, View v, int position, long id)
	{
		String selectedItem = (String) getListView().getItemAtPosition(position);
		TextView wordSizeTextView = (TextView) findViewById(R.id.wordSizeTextView);
		String str = ""+selectedItem.length(); // quick way to convert int to string
		wordSizeTextView.setText(str);
	}

	/** Return words from the input stream that are atleast 2 characters long */
	private Set<String> getWords(BufferedReader br)
	{
		Set<String> words = new HashSet<String>(2000); // store words, no duplicates
		try
		{
	        String line;
			while ((line = br.readLine()) != null)
			{
			    // split on puctuation and space
				String[] wordsOnLine = line.split("[\\p{Punct}\\s}]");
				for (String w : wordsOnLine)
				{
					if (w.trim().length() < 2)
						continue; // ignore empty and single char
					words.add(w.toLowerCase());
				}
			}
		} catch (IOException iox) {} // ignore
		return words;
	}
}